export class User {
    constructor(public id:number,
        public name:String,
        public phoneNumber:String,
        public email:String){

    }
}
